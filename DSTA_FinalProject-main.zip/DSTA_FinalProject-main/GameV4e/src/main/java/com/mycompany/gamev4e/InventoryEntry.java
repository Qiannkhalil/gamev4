
package com.mycompany.gamev4e;

public class InventoryEntry {
    public Item item;
    public int count;
    public InventoryEntry(Item item, int count) { this.item = item; this.count = count; }
}
    

